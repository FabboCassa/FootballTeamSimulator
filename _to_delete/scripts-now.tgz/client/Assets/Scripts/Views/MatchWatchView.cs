using System;
using UnityEngine;
using UnityEngine.UIElements;

namespace Fts.Views
{
    /// <summary>
    /// Chrome for the watchable match (task 3.1): a top HUD (score + clock), a slot the
    /// presenter fills with the live figures, the pitch area (the renderer is inserted by the
    /// presenter), an event toast overlay, and a bottom control bar (speed 0.5x/1x/2x/4x, Skip,
    /// Continue).
    ///
    /// The figures arrive as a whole strip rather than as numbers because the strip is painted in
    /// the two KIT colours, and the kits are the presenter's business — it is the one that resolves
    /// the club identities and guards against a colour clash.
    ///
    /// Dumb view: it raises events and renders what the presenter tells it.
    /// </summary>
    public sealed class MatchWatchView
    {
        private static readonly Color BarColor = UiKit.SurfaceDeep;
        private static readonly Color ToastColor = new Color(0f, 0f, 0f, 0.75f);
        private static readonly Color ActiveSpeed = UiKit.Accent;
        private static readonly Color IdleSpeed = UiKit.SurfaceAlt;
        private static readonly Color SlowMotionChip = new Color(0.95f, 0.72f, 0.20f, 0.92f);
        private static readonly Color SlowMotionText = new Color(0.08f, 0.09f, 0.12f);

        public event Action<float> SpeedClicked;
        public event Action SkipClicked;
        public event Action PauseClicked;
        public event Action ContinueClicked;

        public VisualElement Root { get; }

        /// <summary>Container the presenter drops the MatchRenderer into.</summary>
        public VisualElement PitchContainer { get; }

        /// <summary>Row under the HUD the presenter drops the live-figures strip into.</summary>
        public VisualElement StatsSlot { get; }

        private Label _score;
        private Label _clock;
        private VisualElement _homeCrestSlot;
        private VisualElement _awayCrestSlot;
        private readonly Label _toast;
        private readonly Label _slowMotion;
        private readonly ActionFeed _feed = new ActionFeed();
        private Button _skip;
        private Button _pause;
        private Button _continue;
        private readonly Button[] _speedButtons;
        // 0.5x is not a gimmick: at 1x the director spends half the budget on the strikes and has
        // to run the rest of the match at about thirty-five times real time, which is a lot of
        // football going past. Halving it is the one honest lever on that — a ten-minute match
        // with the ordinary play at a readable pace and the strikes in slow motion proper.
        private readonly float[] _speeds = { 0.5f, 1f, 2f, 4f };
        private IVisualElementScheduledItem _toastHide;

        public MatchWatchView(Func<string, string> tr)
        {
            Root = new VisualElement();
            Root.style.flexGrow = 1f;
            Root.style.backgroundColor = UiKit.HubBlue;

            Root.Add(BuildHud(tr));

            StatsSlot = new VisualElement();
            Root.Add(StatsSlot);

            PitchContainer = new VisualElement();
            PitchContainer.style.flexGrow = 1f; // takes the space between HUD and controls

            // Centered toast overlay: a full-width absolute row so the label
            // centres horizontally and draws on top of the renderer.
            var toastRow = new VisualElement();
            toastRow.style.position = Position.Absolute;
            toastRow.style.left = 0;
            toastRow.style.right = 0;
            toastRow.style.top = 12;
            toastRow.style.flexDirection = FlexDirection.Row;
            toastRow.style.justifyContent = Justify.Center;
            toastRow.pickingMode = PickingMode.Ignore;

            _toast = new Label(string.Empty);
            _toast.style.color = Color.white;
            _toast.AddToClassList("fts-t-strong");
            _toast.style.unityFontStyleAndWeight = FontStyle.Bold;
            _toast.style.backgroundColor = ToastColor;
            _toast.style.paddingLeft = 12;
            _toast.style.paddingRight = 12;
            _toast.style.paddingTop = 6;
            _toast.style.paddingBottom = 6;
            _toast.style.display = DisplayStyle.None;
            toastRow.Add(_toast);

            // The slow-motion chip sits beside the toast: when the director drops playback to real
            // time the picture suddenly crawls, and without a word on screen that reads as a stall.
            _slowMotion = new Label(tr("match.slow_motion"));
            _slowMotion.style.color = SlowMotionText;
            _slowMotion.AddToClassList("fts-t-meta");
            _slowMotion.style.unityFontStyleAndWeight = FontStyle.Bold;
            _slowMotion.style.backgroundColor = SlowMotionChip;
            _slowMotion.style.paddingLeft = 9;
            _slowMotion.style.paddingRight = 9;
            _slowMotion.style.paddingTop = 3;
            _slowMotion.style.paddingBottom = 3;
            _slowMotion.style.marginLeft = 8;
            _slowMotion.style.display = DisplayStyle.None;
            toastRow.Add(_slowMotion);

            PitchContainer.Add(toastRow);
            PitchContainer.Add(_feed.Root);
            _feed.Clear();

            Root.Add(PitchContainer);

            _speedButtons = new Button[_speeds.Length];
            Root.Add(BuildControls(tr));

            SetFinished(false);
        }

        private VisualElement BuildHud(Func<string, string> tr)
        {
            var hud = new VisualElement();
            hud.style.flexDirection = FlexDirection.Row;
            hud.style.justifyContent = Justify.Center;
            hud.style.alignItems = Align.Center;
            hud.style.backgroundColor = BarColor;
            hud.style.paddingTop = 10;
            hud.style.paddingBottom = 10;

            _homeCrestSlot = CrestSlot();
            _homeCrestSlot.style.marginRight = 10;
            hud.Add(_homeCrestSlot);

            _score = new Label(string.Empty);
            _score.AddToClassList("fts-hud__score");
            UiKit.UseDisplayFont(_score);
            _score.style.unityFontStyleAndWeight = FontStyle.Bold;
            _score.style.color = Color.white;
            hud.Add(_score);

            _awayCrestSlot = CrestSlot();
            _awayCrestSlot.style.marginLeft = 10;
            _awayCrestSlot.style.marginRight = 20;
            hud.Add(_awayCrestSlot);

            _clock = new Label("0'");
            _clock.AddToClassList("fts-t-strong");
            _clock.style.color = new Color(1f, 1f, 1f, 0.8f);
            _clock.style.minWidth = 48;
            _clock.style.unityTextAlign = TextAnchor.MiddleLeft;
            hud.Add(_clock);

            return hud;
        }

        private VisualElement BuildControls(Func<string, string> tr)
        {
            var bar = new VisualElement();
            bar.style.flexDirection = FlexDirection.Row;
            bar.style.justifyContent = Justify.Center;
            bar.style.alignItems = Align.Center;
            bar.style.backgroundColor = BarColor;
            bar.style.paddingTop = 8;
            bar.style.paddingBottom = 8;

            string[] speedKeys = { "match.speed_05x", "match.speed_1x", "match.speed_2x", "match.speed_4x" };
            for (int i = 0; i < _speeds.Length; i++)
            {
                float speed = _speeds[i];
                var b = new Button(() => SpeedClicked?.Invoke(speed)) { text = tr(speedKeys[i]) };
                StyleSmall(b);
                _speedButtons[i] = b;
                bar.Add(b);
            }

            _pause = new Button(() => PauseClicked?.Invoke()) { text = tr("match.pause") };
            StyleSmall(_pause);
            _pause.style.marginLeft = 16;
            bar.Add(_pause);

            _skip = new Button(() => SkipClicked?.Invoke()) { text = tr("match.skip") };
            StyleSmall(_skip);
            _skip.style.marginLeft = 16;
            bar.Add(_skip);

            _continue = new Button(() => ContinueClicked?.Invoke()) { text = tr("match.continue") };
            StyleSmall(_continue);
            _continue.style.marginLeft = 16;
            _continue.style.minWidth = 150;
            bar.Add(_continue);

            return bar;
        }

        public void SetScore(string score) => _score.text = score;

        public void SetClock(string clock) => _clock.text = clock;

        /// <summary>Shows the two clubs' crests either side of the score (task 6.8).</summary>
        public void SetCrests(VisualElement home, VisualElement away)
        {
            _homeCrestSlot.Clear();
            if (home != null) _homeCrestSlot.Add(home);
            _awayCrestSlot.Clear();
            if (away != null) _awayCrestSlot.Add(away);
        }

        private static VisualElement CrestSlot()
        {
            var slot = new VisualElement();
            slot.style.width = 32;
            slot.style.minHeight = 32;
            slot.style.alignItems = Align.Center;
            slot.style.justifyContent = Justify.Center;
            return slot;
        }

        /// <summary>Highlights the active speed button.</summary>
        public void SetActiveSpeed(float speed)
        {
            for (int i = 0; i < _speeds.Length; i++)
            {
                _speedButtons[i].style.backgroundColor =
                    Mathf.Approximately(_speeds[i], speed) ? ActiveSpeed : IdleSpeed;
                _speedButtons[i].style.color = Mathf.Approximately(_speeds[i], speed) ? UiKit.TextOnAccent : UiKit.TextPrimary;
            }
        }

        /// <summary>Adds a line to the running commentary beside the pitch (task 13.1).</summary>
        public void PushAction(string text) => _feed.Push(text);

        /// <summary>Empties the commentary (a re-simulated remainder starts fresh).</summary>
        public void ClearActions() => _feed.Clear();

        /// <summary>Shows or hides the real-time slow-motion chip.</summary>
        public void SetSlowMotion(bool on) =>
            _slowMotion.style.display = on ? DisplayStyle.Flex : DisplayStyle.None;

        public void ShowToast(string text)
        {
            _toast.text = text;
            _toast.style.display = DisplayStyle.Flex;
            _toastHide?.Pause();
            _toastHide = _toast.schedule.Execute(() => _toast.style.display = DisplayStyle.None).StartingIn(2500);
        }

        /// <summary>At full time: hide speed/skip, reveal Continue.</summary>
        public void SetFinished(bool finished)
        {
            foreach (Button b in _speedButtons)
                b.style.display = finished ? DisplayStyle.None : DisplayStyle.Flex;
            _skip.style.display = finished ? DisplayStyle.None : DisplayStyle.Flex;
            _pause.style.display = finished ? DisplayStyle.None : DisplayStyle.Flex;
            _continue.style.display = finished ? DisplayStyle.Flex : DisplayStyle.None;
        }

        private static void StyleSmall(Button b)
        {
            b.style.minHeight = 44;
            b.style.minWidth = 56;
            b.AddToClassList("fts-t-strong");
            b.style.marginLeft = 4;
            b.style.marginRight = 4;
            b.style.color = Color.white;
            b.style.backgroundColor = IdleSpeed;
        }
    }
}
