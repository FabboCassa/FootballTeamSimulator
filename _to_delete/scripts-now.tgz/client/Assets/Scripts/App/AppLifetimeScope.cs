using Fts.Services;
using Fts.Services.Messaging;
using Fts.Services.Localization;
using Fts.Services.Navigation;
using Fts.Services.Online;
using Fts.Services.Persistence;
using UnityEngine;
using UnityEngine.UIElements;
using VContainer;
using VContainer.Unity;

namespace Fts.App
{
    /// <summary>
    /// Root (App) DI scope, placed in the Boot scene.
    /// Scope hierarchy: App → Game (active career) → Screen (one per pushed screen).
    /// </summary>
    public sealed class AppLifetimeScope : LifetimeScope
    {
        [SerializeField] private UIDocument uiDocument;

        protected override void Configure(IContainerBuilder builder)
        {
            builder.RegisterComponent(uiDocument);

            builder.Register<IMessageBroker, MessageBroker>(Lifetime.Singleton);
            builder.Register<ScreenNavigator>(Lifetime.Singleton);
            builder.Register<OverlayHost>(Lifetime.Singleton);
            builder.Register<ISaveRepository, LocalJsonSaveRepository>(Lifetime.Singleton);
            builder.Register<CareerFactory>(Lifetime.Singleton);
            builder.Register<ILocalizationService, LocalizationService>(Lifetime.Singleton);
            // Online backend gateway (task 7.2): register/login + rotating token store. Offline-first —
            // single player never needs it; only the online phases do.
            builder.Register<ApiClient>(Lifetime.Singleton);
            // Private-league gateway (task 8.1b): create/join/leave/list online friend leagues.
            builder.Register<LeagueApiService>(Lifetime.Singleton);
            builder.Register<LeagueSelection>(Lifetime.Singleton);
            // Public ranked ladder gateway (task 9.2): enrol + ladder state + season.
            builder.Register<RankedApiService>(Lifetime.Singleton);
            // Ranked replay hand-off (task 9.2): which fixture the ranked replay screen renders.
            builder.Register<RankedReplayTarget>(Lifetime.Singleton);
            // Ranked live hand-off (task 12.3): which fixture the ranked live screen attends.
            builder.Register<RankedLiveTarget>(Lifetime.Singleton);
            // Season replay hand-off (task 8.3b): which fixture the online replay screen renders.
            builder.Register<SeasonReplayTarget>(Lifetime.Singleton);
            builder.Register<IGameSessionService, GameSessionService>(Lifetime.Singleton)
                   .WithParameter<LifetimeScope>(this);

            builder.RegisterEntryPoint<AppEntryPoint>();
            // Mobile foundation (task 6.4): device safe-area insets + adaptive frame rate.
            builder.RegisterEntryPoint<SafeAreaController>();
            builder.RegisterEntryPoint<FrameRateController>();
            // Desktop niceties (task 6.5): fullscreen toggle, run-in-background, Hub hotkeys.
            builder.RegisterEntryPoint<DesktopController>();

            // The navigator's default parent scope for Screen scopes is the App scope.
            builder.RegisterBuildCallback(container =>
                container.Resolve<ScreenNavigator>().SetActiveScope(this));
        }
    }
}
